function displayTime() {
     var info = new Date();
	 
	 var day = info.getDay();
     var hrs = info.getHours();
	 var min = info.getMinutes();
	 var sec = info.getSeconds();
	 var date = info.getDate();
	 
	 var days = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
     var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	 
     var min = ((min < 10) ? "0" + min : min);
	 var sec = ((sec < 10) ? "0" + sec : sec);
	 
	 var rel = "AM";
	 if (hrs >= 12) {
		hrs = hrs - 12;
		rel = "PM";
	}
	if (hrs == 0) {
		hrs = 12;
	}

	 document.getElementById("day").innerHTML = days[day];
	 document.getElementById("date").innerHTML = months[info.getMonth()] + " " + date;
     document.getElementById("time").innerHTML = hrs + ":" + min + " " + rel;

     setTimeout(displayTime, 100);
}
displayTime();
